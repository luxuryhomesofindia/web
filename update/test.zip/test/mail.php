<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/PHPMailer/src/Exception.php';
require __DIR__ . '/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/PHPMailer/src/SMTP.php';

header('Content-Type: text/plain; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Method not allowed'); }

$name    = trim($_POST['name']    ?? '');
$email   = trim($_POST['email']   ?? '');
$message = trim($_POST['message'] ?? '');

// Basic validation
if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $message === '') {
  http_response_code(400);
  exit('Invalid input.');
}

$mail = new PHPMailer(true);

try {
  // ---- GoDaddy/domain SMTP ----
  $mail->isSMTP();
  $mail->Host       = 'smtpout.secureserver.net';  // GoDaddy SMTP
  $mail->SMTPAuth   = true;
  $mail->Username   = 'info@luxuryhomesofindia.in'; // full mailbox username
  $mail->Password   = 'REPLACE_WITH_MAILBOX_PASSWORD';
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;  // SSL
  $mail->Port       = 465;                          // (or 587 with STARTTLS)

  // From must be your domain address
  $mail->setFrom('info@luxuryhomesofindia.in', 'Luxury Homes Website');
  $mail->addReplyTo($email, $name);                 // user who submitted the form

  // Single recipient (as requested)
  $mail->addAddress('info@luxuryhomesofindia.in', 'LHI');

  // Message
  $mail->isHTML(true);
  $mail->Subject = "New enquiry from $name";
  $mail->Body    = "
    <h3>New contact enquiry</h3>
    <p><b>Name:</b> ".htmlspecialchars($name)."</p>
    <p><b>Email:</b> ".htmlspecialchars($email)."</p>
    <p><b>Message:</b><br>".nl2br(htmlspecialchars($message))."</p>
  ";
  $mail->AltBody = "Name: $name\nEmail: $email\n\n$message";

  if (!$mail->send()) {
    http_response_code(500);
    exit('Mailer error: '.$mail->ErrorInfo);
  }

  echo 'Thank you! Your message has been sent.';
} catch (Exception $e) {
  http_response_code(500);
  echo 'Mailer exception: '.$mail->ErrorInfo;
}
