<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $message = $_POST['message'];

    // Recipient email addresses
    $to = "aipromptgowri@gmail.com, gowri7282@gmail.com";  // Multiple recipients separated by a comma

    // Subject of the email
    $subject = "New Contact Form Submission";

    // Email body content
    $body = "You have received a new message from your website contact form.\n\n";
    $body .= "Name: " . htmlspecialchars($name) . "\n";
    $body .= "Email: " . htmlspecialchars($email) . "\n";
    $body .= "Mobile Number: " . htmlspecialchars($mobile) . "\n";
    $body .= "Message: \n" . nl2br(htmlspecialchars($message)) . "\n";

    // Additional headers
    $headers = "From: " . $email . "\r\n";
    $headers .= "Reply-To: " . $email . "\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    // Send the email
    if (mail($to, $subject, $body, $headers)) {
        echo "Thank you for contacting us! Your message has been sent.";
    } else {
        echo "Sorry, there was an error sending your message. Please try again later.";
    }
}
?>
